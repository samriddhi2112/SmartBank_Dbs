<?php
require 'config/config.php';
if (!isset($_SESSION['customer_id'])) { header("Location: login.php"); exit; }

$stmt = $pdo->prepare("SELECT * FROM loans WHERE customer_id = ? ORDER BY created_at DESC");
$stmt->execute([$_SESSION['customer_id']]);
$loans = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head><title>My Loans - MoneyPal</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
    <header>
        <div class="brand">MoneyPal</div>
        <div class="nav-links"><a href="dashboard.php">Back to Dashboard</a></div>
    </header>
    <div class="container">
        <div class="card">
            <h3>My Loan Applications</h3>
            <table>
                <tr><th>Date Applied</th><th>Amount</th><th>Purpose</th><th>Status</th></tr>
                <?php foreach ($loans as $loan): ?>
                <tr>
                    <td><?= $loan['created_at'] ?></td>
                    <td>₹ <?= number_format($loan['amount'], 2) ?></td>
                    <td><?= htmlspecialchars($loan['purpose']) ?></td>
                    <td class="<?= strtolower($loan['status']) ?>"><?= $loan['status'] ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body></html>