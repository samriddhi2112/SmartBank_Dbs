<?php
require 'config/config.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

if (isset($_POST['action']) && isset($_POST['loan_id'])) {
    $loan_id = $_POST['loan_id'];
    $status = ($_POST['action'] == 'approve') ? 'APPROVED' : 'REJECTED';
    $stmt = $pdo->prepare("UPDATE loans SET status = ? WHERE loan_id = ?");
    $stmt->execute([$status, $loan_id]);
}

$total_customers = $pdo->query("SELECT COUNT(*) FROM customers")->fetchColumn();
$total_balance = $pdo->query("SELECT SUM(balance) FROM accounts")->fetchColumn();

$stmt = $pdo->query("SELECT l.*, c.full_name FROM loans l JOIN customers c ON l.customer_id = c.customer_id WHERE l.status = 'PENDING'");
$pending_loans = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head><title>Admin Dashboard - MoneyPal</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
    <header>
        <div class="brand">Admin Portal</div>
        <div class="nav-links"><a href="logout.php" class="btn btn-danger" style="color:white;">Logout</a></div>
    </header>
    <div class="container">
        <div class="card">
            <h3>System Statistics</h3>
            <p>Total Customers: <b><?= $total_customers ?></b></p>
            <p>Total Funds in Bank: <b>₹ <?= number_format($total_balance, 2) ?></b></p>
        </div>
        <div class="card">
            <h3>Pending Loan Approvals</h3>
            <table>
                <tr><th>Customer Name</th><th>Amount</th><th>Purpose</th><th>Action</th></tr>
                <?php foreach ($pending_loans as $loan): ?>
                <tr>
                    <td><?= htmlspecialchars($loan['full_name']) ?></td>
                    <td>₹ <?= number_format($loan['amount'], 2) ?></td>
                    <td><?= htmlspecialchars($loan['purpose']) ?></td>
                    <td>
                        <form method="POST" style="flex-direction:row;">
                            <input type="hidden" name="loan_id" value="<?= $loan['loan_id'] ?>">
                            <button type="submit" name="action" value="approve" class="btn btn-success">Approve</button>
                            <button type="submit" name="action" value="reject" class="btn btn-danger">Reject</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body></html>