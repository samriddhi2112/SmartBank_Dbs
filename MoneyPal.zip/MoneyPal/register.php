<?php
require 'config/config.php';
$error = ""; $success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($name) && !empty($email) && !empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("INSERT INTO customers (full_name, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$name, $email, $hashed_password]);
            $customer_id = $pdo->lastInsertId();

            $acc_num = "SB" . rand(10000000, 99999999);
            $stmt2 = $pdo->prepare("INSERT INTO accounts (customer_id, account_number, account_type, balance) VALUES (?, ?, 'SAVINGS', 0.00)");
            $stmt2->execute([$customer_id, $acc_num]);

            $pdo->commit();
            $success = "Registration successful! You can now login.";
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Email already exists.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Register - MoneyPal</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body class="auth-body">
    <div class="auth-container">
        <h2>Register</h2>
        <?php if($error): ?><div class="alert error"><?= $error ?></div><?php endif; ?>
        <?php if($success): ?><div class="alert success"><?= $success ?></div><?php endif; ?>
        <form method="POST">
            <input type="text" name="full_name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email Address" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Create Account</button>
        </form>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body></html>