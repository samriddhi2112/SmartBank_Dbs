<?php
require 'config/config.php';
if (!isset($_SESSION['customer_id'])) { header("Location: login.php"); exit; }

$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = (float)$_POST['amount'];
    $purpose = $_POST['purpose'];

    if ($amount > 0) {
        $stmt = $pdo->prepare("INSERT INTO loans (customer_id, amount, purpose) VALUES (?, ?, ?)");
        $stmt->execute([$_SESSION['customer_id'], $amount, $purpose]);
        $message = "<div class='alert success'>Loan application submitted! Wait for Admin approval.</div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Apply Loan - MoneyPal</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
    <header>
        <div class="brand">MoneyPal</div>
        <div class="nav-links"><a href="dashboard.php">Back to Dashboard</a></div>
    </header>
    <div class="container">
        <div class="card">
            <h3>Apply for a Loan</h3>
            <?= $message ?>
            <form method="POST">
                <input type="number" step="0.01" name="amount" placeholder="Loan Amount Required (₹)" required>
                <input type="text" name="purpose" placeholder="Purpose of Loan" required>
                <button type="submit" class="btn">Submit Application</button>
            </form>
        </div>
    </div>
</body></html>