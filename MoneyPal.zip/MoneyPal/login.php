<?php
require 'config/config.php';
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];

    if ($role == 'admin') {
        $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();
        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['admin_id'];
            header("Location: admin_dashboard.php");
            exit;
        } else { $error = "Invalid admin credentials."; }
    } else {
        $stmt = $pdo->prepare("SELECT * FROM customers WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['customer_id'] = $user['customer_id'];
            $_SESSION['customer_name'] = $user['full_name'];
            header("Location: dashboard.php");
            exit;
        } else { $error = "Invalid email or password."; }
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Login - MoneyPal</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body class="auth-body">
    <div class="auth-container">
        <h2>Welcome to MoneyPal</h2>
        <?php if($error): ?><div class="alert error"><?= $error ?></div><?php endif; ?>
        <form method="POST">
            <select name="role"><option value="customer">Customer</option><option value="admin">Admin</option></select>
            <input type="text" name="email" placeholder="Email or Admin Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
        <p>New customer? <a href="register.php">Register here</a></p>
    </div>
</body></html>