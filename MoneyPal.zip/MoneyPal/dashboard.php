<?php
require 'config/config.php';
if (!isset($_SESSION['customer_id'])) { header("Location: login.php"); exit; }

$customer_id = $_SESSION['customer_id'];
$message = "";

if (isset($_POST['do_action'])) {
    $action = $_POST['action'];
    $from = $_POST['from_account'];
    $to = $_POST['to_account'] ?? '';
    $amount = (float)$_POST['amount'];

    if($amount > 0) {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT * FROM accounts WHERE account_id=? FOR UPDATE");
            $stmt->execute([$from]);
            $acc = $stmt->fetch();

            if ($action === 'deposit') {
                $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE account_id=?")->execute([$amount, $from]);
                $pdo->prepare("INSERT INTO transactions (account_id, txn_type, amount, description) VALUES (?,?,?,?)")->execute([$from, 'CREDIT', $amount, 'Self Deposit']);
                $message = "<div class='alert success'>Deposit successful!</div>";
            }
            elseif ($action === 'withdraw') {
                if ($acc['balance'] < $amount) throw new Exception("Insufficient balance.");
                $pdo->prepare("UPDATE accounts SET balance = balance - ? WHERE account_id=?")->execute([$amount, $from]);
                $pdo->prepare("INSERT INTO transactions (account_id, txn_type, amount, description) VALUES (?,?,?,?)")->execute([$from, 'DEBIT', $amount, 'Self Withdrawal']);
                $message = "<div class='alert success'>Withdrawal successful!</div>";
            }
            elseif ($action === 'transfer') {
                if ($acc['balance'] < $amount) throw new Exception("Insufficient balance.");
                $stmt = $pdo->prepare("SELECT * FROM accounts WHERE account_number=? FOR UPDATE");
                $stmt->execute([$to]);
                $toAcc = $stmt->fetch();
                if (!$toAcc) throw new Exception("Invalid target account.");
                
                $pdo->prepare("UPDATE accounts SET balance = balance - ? WHERE account_id=?")->execute([$amount, $from]);
                $pdo->prepare("UPDATE accounts SET balance = balance + ? WHERE account_id=?")->execute([$amount, $toAcc['account_id']]);
                $pdo->prepare("INSERT INTO transactions (account_id, txn_type, amount, description) VALUES (?,?,?,?)")->execute([$from, 'DEBIT', $amount, "Transfer to ".$to]);
                $pdo->prepare("INSERT INTO transactions (account_id, txn_type, amount, description) VALUES (?,?,?,?)")->execute([$toAcc['account_id'], 'CREDIT', $amount, "Received from ".$acc['account_number']]);
                $message = "<div class='alert success'>Transfer successful!</div>";
            }
            $pdo->commit();
        } catch (Exception $e) {
            $pdo->rollBack();
            $message = "<div class='alert error'>".$e->getMessage()."</div>";
        }
    }
}

$stmt = $pdo->prepare("SELECT * FROM accounts WHERE customer_id=?");
$stmt->execute([$customer_id]);
$accounts = $stmt->fetchAll();
$selected = $_GET['account_id'] ?? ($accounts[0]['account_id'] ?? null);

$transactions = [];
if($selected) {
    $stmt = $pdo->prepare("SELECT * FROM transactions WHERE account_id=? ORDER BY created_at DESC");
    $stmt->execute([$selected]);
    $transactions = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html>
<head><title>Dashboard - MoneyPal</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
    <header>
        <div class="brand">MoneyPal</div>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="apply_loan.php">Apply for Loan</a>
            <a href="loan_details.php">My Loans</a>
            <a href="logout.php" class="btn btn-danger" style="color:white;">Logout</a>
        </div>
    </header>

    <div class="container">
        <h2>Welcome, <?= htmlspecialchars($_SESSION['customer_name']) ?></h2>
        <?= $message ?>
        <div class="card">
            <h3>Your Accounts</h3>
            <?php foreach ($accounts as $acc): ?>
            <a class="account-link" href="?account_id=<?= $acc['account_id'] ?>">
                <?= $acc['account_number'] ?> (<?= $acc['account_type'] ?>)
                <div class="balance">₹ <?= number_format($acc['balance'],2) ?></div>
            </a>
            <?php endforeach; ?>
        </div>
        <div class="card">
            <h3>Quick Transaction</h3>
            <form method="post">
                <select name="action" required><option value="deposit">Deposit</option><option value="withdraw">Withdraw</option><option value="transfer">Transfer</option></select>
                <select name="from_account" required>
                    <?php foreach ($accounts as $acc): ?><option value="<?= $acc['account_id'] ?>"><?= $acc['account_number'] ?></option><?php endforeach; ?>
                </select>
                <input type="text" name="to_account" placeholder="To Account Number (Transfers only)">
                <input type="number" step="0.01" name="amount" placeholder="Amount" required>
                <button type="submit" name="do_action" class="btn">Submit Transaction</button>
            </form>
        </div>
        <div class="card">
            <h3>Recent Transactions</h3>
            <table>
                <tr><th>Date</th><th>Type</th><th>Amount</th><th>Description</th></tr>
                <?php foreach ($transactions as $t): ?>
                <tr>
                    <td><?= $t['created_at'] ?></td>
                    <td><?= $t['txn_type'] ?></td>
                    <td class="<?= $t['txn_type']=='CREDIT'?'credit':'debit' ?>">₹ <?= number_format($t['amount'],2) ?></td>
                    <td><?= $t['description'] ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body></html>