<?php
require 'config/config.php';

$username = 'admin';
$password = 'admin123';

// 1. Generate a mathematically perfect hash for your specific server
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// 2. Delete the old broken admin account
$pdo->query("DELETE FROM admins WHERE username = 'admin'");

// 3. Insert the new fixed admin account
$stmt = $pdo->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
$stmt->execute([$username, $hashed_password]);

echo "<h2>Success! The admin account is fixed.</h2>";
echo "<p>You can now go to <a href='login.php'>login.php</a> and log in with:</p>";
echo "<ul><li><b>Role:</b> Admin</li><li><b>Username:</b> admin</li><li><b>Password:</b> admin123</li></ul>";
?>